#include <iostream>
#include <string>
#include <conio.h>
#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;


class InputType
{
    public:
    string Title;
    int Type=1;
};

string get_template(int type)
{
    std::ifstream controlTemplate;
    if(type == 1)
    {
        controlTemplate.open("ControlTemplate.txt");
    }
    else if(type == 2)
    {
        controlTemplate.open("EmailTemplate.txt");
    }
    else if(type == 3)
    {
        controlTemplate.open("AddressTemplate.txt");
    }
    else if(type == 4)
    {
        controlTemplate.open("PaymentTemplate.txt");
    }
    else{
        controlTemplate.open("ControlTemplate.txt");
    }
     //open the input file

    std::stringstream controlStream;
    controlStream << controlTemplate.rdbuf(); //read the file
    std::string controlTemplateString = controlStream.str();
    return controlTemplateString;
}

int main() {
    int num=0;
    cout << "Welcome to form builder" << endl;
    cout << "Press enter to start" << endl;
    getch();
    cout << "Enter number of controls" << endl;
    cin >> num;
    int i=0;

    ofstream myfile;
    InputType control_array[num]    ;
    string FormTitle;
    string Description;
    cout << "Enter the Form Title"<< endl;
    std::getline(std::cin >> std::ws, FormTitle);
    cout << "Enter the Description" << endl;
    std::getline(std::cin >> std::ws, Description);
    myfile.open ("example.html");
    do
    {
        /* code */
        string title;
        int type=1;
        cout << "Enter title for the field no.: " << i <<endl;
        cin >> title;
        cout << "Select field type: \n1: Basic Input\n2: Email\n3: Address\n4: Payment";
        cin >> type;
        InputType control;
        control.Title = title;
        control.Type = type;
        control_array[i] = control; 
        i++;
    } while (i<num);
    i=0;
    cout << "Showing input titles" <<endl;
   
    std::string controlTemplateString = get_template(1); //str holds the content of the file
    string controls;
    string modifiedTemplate;
    modifiedTemplate=controlTemplateString;
    controls= "";
    while (i<num)
    {
        cout << i;
        cout << control_array[i].Title;
        controlTemplateString = get_template(control_array[i].Type);
         modifiedTemplate=controlTemplateString;
        if( control_array[i].Type == 1)
        {
            modifiedTemplate = modifiedTemplate.insert(79,  control_array[i].Title);

        }
        else if ( control_array[i].Type == 2)
        {
            modifiedTemplate = modifiedTemplate.insert(76,  control_array[i].Title);
        }
        else if ( control_array[i].Type == 3)
        {
            
            modifiedTemplate = modifiedTemplate.insert(76,  control_array[i].Title);
        }
        else if ( control_array[i].Type == 4)
        {
            
            modifiedTemplate = modifiedTemplate.insert(17,  control_array[i].Title);
        }
        
        
        controls.append(modifiedTemplate);
        i++;
        modifiedTemplate=controlTemplateString;
    }
    // myfile << "Enter title for the field.\n";
   
    std::ifstream inFile;
    inFile.open("HtmlTemplate.html"); //open the input file

    std::stringstream strStream;
    strStream << inFile.rdbuf(); //read the file
    std::string str = strStream.str(); //str holds the content of the file
    cout << "Form Title";
    str.insert(6907, FormTitle);
    str.insert(7134+ FormTitle.length() - 1, Description);
   str.insert(7156 + FormTitle.length() + Description.length() -2, controls);
    myfile << str;
    myfile.close();

    
}